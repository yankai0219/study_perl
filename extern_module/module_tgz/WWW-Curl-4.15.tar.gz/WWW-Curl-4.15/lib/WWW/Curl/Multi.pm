package WWW::Curl::Multi;

use strict;
use warnings;
use WWW::Curl;

1;
__END__

Copyright (C) 2004 Sebastian Riedel, et al.

You may opt to use, copy, modify, merge, publish, distribute and/or sell
copies of the Software, and permit persons to whom the Software is furnished
to do so, under the terms of the MPL or the MIT/X-derivate licenses. You may
pick one of these licenses.
